﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace IIS
{
    /// <summary>
    /// Summary description for ImmunizationInformationSystemService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ImmunizationInformationSystemService : client_Service
    {

        [WebMethod]
        public string connectivityTest([System.Xml.Serialization.XmlElementAttribute(IsNullable = true)] string echoBack)
        {
            return "ConnectivityTest";
        }

        [WebMethod]
        public string submitSingleMessage([System.Xml.Serialization.XmlElementAttribute(IsNullable = true)] string username,
                                          [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)] string password,
                                          [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)] string facilityID,
                                           [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)] string hl7Message)
        {

            // 1. authenticate username, password and faciltiy ID combo
            // 2. parse hl7 message and determine course of action (VXQ, VXU)
            // 3. process request and generate a response

            return "SubmitSingleMessage";
        }
    }
}