﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(System.Object sender, System.EventArgs e)
        {
            try
            {
                ImmunizationService.client_Service service = new ImmunizationService.client_Service();
                Response.Text = service.submitSingleMessage(Username.Text, Password.Text, FacilityID.Text, HL7Message.Text);
            }
            catch
            {
                Response.Text = "Request failed.";
            }
        }
    }
}
