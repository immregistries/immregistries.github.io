﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Search_Click(object sender, EventArgs e)
        {
            ImmunizationService.client_Service service = new ImmunizationService.client_Service(); 
            CIRAccount cirAccount = new CIRAccount();
            VXU vxu = new VXU();
            //inject immunization information into VXU
            service.submitSingleMessage(cirAccount.getUserId(), 
                                        cirAccount.getPassword(), 
                                        cirAccount.getFacilityId(),
                                        vxu.toHL7String());

        }
    }
}