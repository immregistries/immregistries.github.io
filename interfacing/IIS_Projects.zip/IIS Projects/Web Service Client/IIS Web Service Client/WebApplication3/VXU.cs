﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3
{
    public class VXU
    {
        public void setPatientFirstName(String firstName) { }

        public void setPatientLastName(String lastName) { }

        public void setPatientDateOfBirth(String dateOfBirth) { }

        public void setPatientGender(String gender) { }

        public String toHL7String() { return ""; }
    }
}